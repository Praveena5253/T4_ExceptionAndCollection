package com.task4;

import java.util.Scanner;

class InvalidAgeException extends Exception {
	public InvalidAgeException(String msg) {
		super(msg);
	}
}

public class Voter {
	private String voterId;
	private String name;
	private int age;

	public Voter(String voterId, String name, int age)throws InvalidAgeException {
		if(age < 18)
			throw new InvalidAgeException("Invalid age for voter");
		this.voterId = voterId;
		this.name = name;
		this.age = age;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int age;
		String voterId, name;
		System.out.println("Enter the voterId: ");
		voterId = s.next();
		System.out.println("Enter the Name: ");
		name = s.next();
		System.out.println("Enter the Age: ");
		age = s.nextInt();

		try {
			Voter v = new Voter(voterId, name, age);
			System.out.println("\n" + name + " is eligible to vote");
		} catch (InvalidAgeException e) {
			System.out.println("\nException occured: " + e.getMessage());
		}
	}
}
