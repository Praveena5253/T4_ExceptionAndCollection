package com.task4;

import java.util.HashMap;
import java.util.TreeMap;

public class StudentGradeHashMap {

	public static void main(String[] args) {
		// Creating a new HashMap
		HashMap<String, Integer> map = new HashMap<>();

		// Adding key-value pairs to the HashMap (Create)
		map.put("Paul", 8);
		map.put("Simon", 6);
		map.put("Lee", 9);
		map.put("Codd", 7);
		System.out.println("Initial map: " + map);

		// Retrieving a value from the HashMap (Read)
		Integer value = map.get("Simon"); // Retrieve the value associated with key "Simon"
		System.out.println("Value for key \"Simon\": " + value);

		// Updating the value associated with a specific key
		map.put("Codd", 6); // Update the value associated with key "Codd"
		System.out.println("Map after updating key \"Codd\": " + map);

		// Removing a key-value pair from the HashMap (Delete)
		map.remove("Simon"); // Remove the key-value pair associated with key "Simon"
		System.out.println("Map after removing key \"Simon\": " + map);

		// Display student's grade by name
		TreeMap<String, Integer> tmap = new TreeMap<>(map);
		System.out.println("\nStudent's grade by name: " + tmap);

	}

}
