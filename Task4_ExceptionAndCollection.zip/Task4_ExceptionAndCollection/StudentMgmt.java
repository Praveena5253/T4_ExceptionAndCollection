package com.task4;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class AgeNotWithinRangeException extends Exception {
	public AgeNotWithinRangeException(String str) {
		super(str);
	}
}

class NameNotValidException extends Exception {
	public NameNotValidException(String str) {
		super(str);
	}
}

class Student {
	private int rollNo;
	private String name;
	private int age;
	private String course;

	public Student(int rollNo, String name, int age, String course) throws AgeNotWithinRangeException, NameNotValidException {
		if(age < 15 || age > 21)
			throw new AgeNotWithinRangeException("Age is not within the range of 15 and 21");

		Pattern pattern = Pattern.compile("[a-zA-Z]*");
		Matcher matcher = pattern.matcher(name); 
		if (!matcher.matches()) {
			throw new NameNotValidException("Name includes special characters or numbers");	
		} 

		this.rollNo = rollNo;
		this.name = name;
		this.age = age;
		this.course = course;
	}	
}


public class StudentMgmt {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int rollNo, age;
		String name, course;
		System.out.println("Enter the RollNo: ");
		rollNo = s.nextInt();
		System.out.println("Enter the Name: ");
		name = s.next();
		System.out.println("Enter the Age: ");
		age = s.nextInt();
		System.out.println("Enter the Course: ");
		course = s.next();

		try  
		{  			
			Student s1 = new Student(rollNo,name,age,course);
			System.out.println("\nStudent successfully registered!!");
		}  
		catch (AgeNotWithinRangeException ex)  
		{      
			// printing the message from AgeNotWithinRangeException  
			System.out.println("\nException occured: " + ex);  
		}  
		catch (NameNotValidException ex)  
		{      
			// printing the message from NameNotValidException 
			System.out.println("\nException occured: " + ex);  
		}  
	}
}
