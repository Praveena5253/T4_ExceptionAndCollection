package com.task4;

import java.util.Stack;

public class StackCollection {

	public static void main(String[] args) {
		// an empty Stack created 
		Stack<Integer> stk = new Stack<Integer>();  

		// push() method is used to add elements  
		stk.push(32);  
		stk.push(74);  
		stk.push(59);  
		stk.push(81);  

		// Display the contents of Stack  
		System.out.println("Contents of Stack after addition of elements: " + stk);  

		// Delete elements of stack using pop() method 
		System.out.println("\nPopped element 1: " +stk.pop());  
		System.out.println("Popped element 2: " +stk.pop()); 

		// Display the Stack after deletion  
		System.out.println("\nContents of Stack after deletion of elements: " + stk); 

		// Verifying if the Stack is empty or not 
		System.out.println("\nIs the Stack empty? " + stk.isEmpty()); 
	}

}
