package com.task4;

import java.util.Scanner;

class DayIndexOutsideRangeException extends Exception {
	public DayIndexOutsideRangeException(String msg) {
		super(msg);
	}
}

public class Weekdays {

	public static void main(String[] args) throws DayIndexOutsideRangeException {
		int dayPosition;
		Scanner s = new Scanner(System.in);
		String[] days = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
		System.out.println("Enter the day index: ");
		dayPosition = s.nextInt();
		try {
			if(dayPosition < 0 || dayPosition > 6) {

				throw new DayIndexOutsideRangeException("Day index provided is outside range (0-6)");
			}

			else {
				switch(dayPosition) {
				case 0: System.out.println("It is Sunday");
				break;
				case 1: System.out.println("It is Monday");
				break;
				case 2: System.out.println("It is Tuesday");
				break;
				case 3: System.out.println("It is Wednesday");
				break;
				case 4: System.out.println("It is Thursday");
				break;
				case 5: System.out.println("It is Friday");
				break;
				case 6: System.out.println("It is Saturday");
				break;
				}
			}
		} catch(DayIndexOutsideRangeException ex) {
			System.out.println("\nException occured: " + ex.getMessage());
		}
	}

}
